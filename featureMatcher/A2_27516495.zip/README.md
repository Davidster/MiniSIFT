## Pip packages

  - Pillow
  - opencv

## 

Click 0 to quit